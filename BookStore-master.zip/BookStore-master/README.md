# BookStore
Spring Boot web application with Spring MVC, Thymeleaf, JPA, Hibernate and Oracle Database.
